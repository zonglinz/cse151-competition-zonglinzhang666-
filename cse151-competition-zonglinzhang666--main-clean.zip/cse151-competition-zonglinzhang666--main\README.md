# CSE151B SP26 Competition Submission

This repository contains the final inference pipeline for the CSE151B Spring 2026 math reasoning competition.

The required single entry point is:

```python
from run_inference import run_inference

run_inference(
    private_path="private.jsonl",
    output_csv="submission.csv",
)
```

This loads Qwen, runs inference on the private set, votes/extracts/reboxes the model-produced answers, and writes a valid Kaggle CSV with columns:

```csv
id,response
```

## Model

Base model:

```text
Qwen/Qwen3-4B-Thinking-2507
```

No final fine-tuned checkpoint was used for the submitted run. Earlier LoRA/QLoRA experiments were validation-only and were not used in the final selected submission.

## GPU And Approximate Runtime

Main GPU used:

```text
NVIDIA RTX 4090 24GB
```

Approximate runtime for a full fresh private run with the final settings:

```text
24 to 40 hours on one RTX 4090, depending on vLLM version, CUDA setup, batching, and cache state.
```

Final CSV validation/copy logic is CPU-only and takes less than a minute.

## Setup

Install a CUDA-enabled Python environment. The pipeline was tested with Python 3.10/3.11 and vLLM.

```bash
pip install -r requirements.txt
```

The model weights are downloaded automatically from HuggingFace Hub by vLLM or Transformers:

```text
Qwen/Qwen3-4B-Thinking-2507
```

If you already downloaded the weights, pass the local model directory as `model_id`:

```python
run_inference(model_id="/path/to/Qwen3-4B-Thinking-2507")
```

For local reproduction, place the competition input files in the repository root before running inference:

```text
private.jsonl
```

Do not commit dataset files unless the course staff explicitly requests them. The starter `judger.py` is only needed for optional local validation/scoring helpers.

## Reproduce Final Submission

Default final profile, matching `submissions/submission.csv`:

```bash
python run_inference.py \
  --private-path private.jsonl \
  --output-csv submission.csv \
  --engine auto \
  --profile v106
```

`profile v106` keeps final answer values from the main Qwen model-inference/voting pipeline. No private id to numeric-answer replacement profile is used.

Second rule-compatible candidate:

```bash
python run_inference.py \
  --private-path private.jsonl \
  --output-csv submission_v121.csv \
  --engine auto \
  --profile v121
```

`profile v121` first runs the same v106-style Qwen pass, then runs a second Qwen MCQ elimination pass and changes only MCQ rows where the second model-produced option letter differs. This is adaptive inference, not a hard-coded numeric repair map.

## Top-10 Full Private Verification

For a full private-set rerun, use the same single entry point:

```bash
python run_inference.py --private-path private.jsonl --output-csv submission.csv --engine auto --profile v106
```

This command does not require any precomputed CSV. It loads Qwen, generates responses for every row in `private.jsonl`, votes/extracts/reboxes model-produced answers inside `run_inference()`, validates id coverage, and writes the final CSV.

The included `submissions/submission.csv` is the submitted reference output for the model-inference/voting pipeline. It is included for comparison; the reproducible path is the command above.

## Inference Hyperparameters

The final run uses these settings inside `run_inference.py`:

```text
seed = 151
engine = auto, preferring vLLM and falling back to Transformers
temperature = 0.6
top_p = 0.95
top_k = 20
max_tokens = 32768
max_model_len = 131072
samples_simple = 4
samples_hard = 12
batch_size = 8
force_final_from_partial = True
v121 MCQ elimination pass = 1 sample, max_tokens = 26000, prompt style = elimination
```

The raw Qwen generation is handled by `cse151b_qwen_highscore.py`. During generation, the code extracts the model's final boxed answer, votes across model samples, and appends a canonical final `\boxed{...}` line to reduce extraction failures. This formatting keeps the answer value produced by model inference.

For public/development JSONL files that contain an `answer` field, use the same profile:

```bash
python run_inference.py --private-path public.jsonl --output-csv public_smoke.csv --engine auto --profile v106
```

## Files To Keep In The Repo

Required:

```text
README.md
run_inference.py
cse151b_qwen_highscore.py
validate_submission.py
requirements.txt
submissions/submission.csv
```

Optional but useful:

```text
requirements_vllm.txt
submissions/submission_v106_jump_hardvote_probe.csv
submissions/submission_v121_mcqelim26000_letterchanges_on_v106.csv
```

Do not commit local model caches, `.venv`, or large temporary logs/checkpoints unless required by the instructor.
